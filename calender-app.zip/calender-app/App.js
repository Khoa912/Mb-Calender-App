import React, { useState, useRef } from 'react';
import {
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Animated,
} from 'react-native';
import { Calendar, LocaleConfig } from 'react-native-calendars';
import Modal from 'react-native-modal';
import { PanGestureHandler, State } from 'react-native-gesture-handler';
import moment from 'moment';

LocaleConfig.locales['en'] = {
  monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  monthNamesShort: ['Jan.', 'Feb.', 'Mar.', 'Apr.', 'May', 'Jun.', 'Jul.', 'Aug.', 'Sep.', 'Oct.', 'Nov.', 'Dec.'],
  dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  today: 'Today'
};
LocaleConfig.defaultLocale = 'en';

const CustomCalendar = () => {
  const [selectedDate, setSelectedDate] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [note, setNote] = useState('');
  const [location, setLocation] = useState('');
  const [noteColor, setNoteColor] = useState('blue');
  const [savedNotes, setSavedNotes] = useState({});
  const translateY = useRef(new Animated.Value(500)).current;

  const handleDayPress = (day) => {
    const selectedDateString = day.dateString;
    setSelectedDate(selectedDateString);

    const selectedNote = savedNotes[selectedDateString]?.note || '';
    const selectedLocation = savedNotes[selectedDateString]?.location || '';

    setNote(selectedNote);
    setLocation(selectedLocation);
    setNoteColor(savedNotes[selectedDateString]?.color || 'blue');
    setIsModalVisible(true);
    Animated.timing(translateY, {
      toValue: 0,
      duration: 500,
      useNativeDriver: false,
    }).start();
  };

  const toggleModal = () => {
    Animated.timing(translateY, {
      toValue: 500,
      duration: 300,
      useNativeDriver: false,
    }).start(() => {
      setIsModalVisible(!isModalVisible);
    });
  };

  const saveNote = () => {
    setSavedNotes((prevNotes) => ({
      ...prevNotes,
      [selectedDate]: { note, location, color: noteColor },
    }));
    toggleModal();
  };

  const deleteNote = () => {
    const { [selectedDate]: deletedNote, ...remainingNotes } = savedNotes;
    setSavedNotes(remainingNotes);
    toggleModal();
  };

  const formattedDate = moment(selectedDate).format('DD-MM-YYYY');

  const markedDates = {};
  Object.keys(savedNotes).forEach((date) => {
    markedDates[date] = { selected: true, marked: true, dotColor: savedNotes[date].color };
  });

  return (
    <View style={styles.container}>
      <Calendar
        onDayPress={handleDayPress}
        markedDates={markedDates}
        style={{
          width: 350,
          height: 400,
        }}
      />

      <Modal isVisible={isModalVisible} onBackdropPress={toggleModal} style={styles.modal}>
        <PanGestureHandler
          onGestureEvent={(event) => {
            translateY.setValue(event.nativeEvent.translationY);
          }}
          onHandlerStateChange={(event) => {
            if (event.nativeEvent.state === State.END) {
              if (event.nativeEvent.translationY < -100) {
                // Swipe up, close modal
                toggleModal();
              }
            }
          }}
        >
          <Animated.View
            style={[
              styles.modalContainer,
              {
                transform: [{ translateY }],
              },
            ]}
          >
            <Text style={styles.modalTitle}>Lời nhắc cho {formattedDate}</Text>
            <TextInput
              style={styles.input}
              placeholder="Nhập ghi chú"
              multiline
              value={note}
              onChangeText={setNote}
            />
            <TextInput
              style={styles.input}
              placeholder="Nhập địa điểm"
              value={location}
              onChangeText={setLocation}
            />
            <TextInput
              style={styles.input}
              placeholder="Chọn nhãn màu (e.g., blue, red)"
              value={noteColor}
              onChangeText={setNoteColor}
            />
            <TouchableOpacity style={styles.saveButton} onPress={saveNote}>
              <Text style={styles.saveButtonText}>Lưu</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.deleteButton} onPress={deleteNote}>
              <Text style={styles.deleteButtonText}>Xóa</Text>
            </TouchableOpacity>

            {savedNotes[selectedDate] && (
              <ScrollView style={styles.savedNoteContainer}>
                <Text style={styles.savedNoteTitle}>Ghi chú:</Text>
                <Text>{savedNotes[selectedDate].note}</Text>
                <Text style={styles.savedNoteTitle}>Địa điểm:</Text>
                <Text>{savedNotes[selectedDate].location}</Text>
              </ScrollView>
            )}
          </Animated.View>
        </PanGestureHandler>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    bottom: 180,
  },
  modalContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    position: 'top',
    bottom: 60,
    left: 0,
    right: 0,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color:'red',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
  },
  saveButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
  },
  deleteButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  savedNoteContainer: {
    maxHeight: 100,
  },
  savedNoteTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  modal: {
    margin: 0,
  },
});

export default CustomCalendar;
